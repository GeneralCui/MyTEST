//
//  myTabBarController.m
//  WKWebviewTest
//
//  Created by tzh on 2017/11/17.
//  Copyright © 2017年 mirroon. All rights reserved.
//

#import "myTabBarController.h"
#import "LeftViewController.h"
#import "RightViewController.h"

@interface myTabBarController ()

@end

@implementation myTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
