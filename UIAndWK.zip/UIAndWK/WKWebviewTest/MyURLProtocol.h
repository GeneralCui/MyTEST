//
//  MyURLProtocol.h
//  WKWebviewTest
//
//  Created by Zhihui Tian on 2017/11/16.
//  Copyright © 2017年 mirroon. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface MyURLProtocol : NSURLProtocol
@end

