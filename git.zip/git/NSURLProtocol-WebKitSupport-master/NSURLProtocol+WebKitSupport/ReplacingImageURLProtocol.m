//
//  ReplacingImageURLProtocol.m
//  NSURLProtocol+WebKitSupport
//
//  Created by yeatse on 2016/10/11.
//  Copyright © 2016年 Yeatse. All rights reserved.
//

#import "ReplacingImageURLProtocol.h"

#import <UIKit/UIKit.h>

static NSString* const FilteredKey = @"FilteredKey";

@implementation ReplacingImageURLProtocol

// 客户端所有请求都走这里，是否拦截处理指定的请求
// @param request 指定的请求
// @return 返回YES表示要拦截处理，返回NO表示不拦截处理
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    
    NSString* extension = request.URL.pathExtension;
    BOOL isImage = [@[@"png", @"jpeg", @"gif", @"jpg"] indexOfObjectPassingTest:^BOOL(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        return [extension compare:obj options:NSCaseInsensitiveSearch] == NSOrderedSame;
    }] != NSNotFound;
    //防止无限循环，因为一个请求在被拦截处理过程中，也会发起一个请求，这样又会走到这里，如果不进行处理，就会造成无限循环
    return [NSURLProtocol propertyForKey:FilteredKey inRequest:request] == nil && isImage;
}
// 如果需要对请求进行重定向，添加指定头部等操作，可以在该方法中进行
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request {
    return request;
}

// 开始加载，在该方法中，加载一个请求
- (void)startLoading {
    NSMutableURLRequest* request = self.request.mutableCopy;
    //表示该请求已经被处理, 防止无限循环,
    [NSURLProtocol setProperty:@YES forKey:FilteredKey inRequest:request];
    
    // 加载本地离线缓存文件
    NSData* data = UIImagePNGRepresentation([UIImage imageNamed:@"image"]);
    NSURLResponse* response = [[NSURLResponse alloc] initWithURL:self.request.URL MIMEType:@"image/png" expectedContentLength:data.length textEncodingName:nil];
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageAllowed];
    [self.client URLProtocol:self didLoadData:data];
    [self.client URLProtocolDidFinishLoading:self];
    
    
}
// 取消请求
- (void)stopLoading {
}

@end

