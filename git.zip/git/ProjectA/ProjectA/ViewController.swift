//
//  ViewController.swift
//  ProjectA
//
//  Created by tzh on 2017/11/09.
//  Copyright © 2017年 tzh. All rights reserved.
//


import UIKit
import WebKit

class ViewController: UIViewController, UITextFieldDelegate, WKNavigationDelegate, UIWebViewDelegate{
    var myTextField :UITextField!
    var myWebView :WKWebView!
    var myActivityIndicator:UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let cls = NSClassFromString("WKBrowsingContextController")
//
//        let sel = NSSelectorFromString("registerSchemeForCustomProtocol:")
//
//        if (Any.cls, responds(to: sel)) {
//            [(Any)cls cancelPerformSelectors(withTarget: <#T##Any#>) ]
//            [(Any)cls cancelPreviousPerformRequests(withTarget: , selector: <#T##Selector#>, object: <#T##Any?#>) ]
//
//        }

           
        // 取得螢幕的尺寸
        let fullScreenSize = UIScreen.main.bounds.size
        
        // 預設尺寸
        let goWidth = 100.0
        let actionWidth = ( Double(fullScreenSize.width) - goWidth ) / 4
        
        
        // 建立五個 UIButton
        let myButton1 = UIButton(frame: CGRect(x: 0, y: 20, width: actionWidth, height: actionWidth))
        myButton1.setImage(UIImage(named: "back")!, for: .normal)
        myButton1.addTarget(self, action: #selector(ViewController.back), for: .touchUpInside)
        self.view.addSubview(myButton1)
        
        let myButton2 = UIButton(frame: CGRect(x: actionWidth, y: 20, width: actionWidth, height: actionWidth))
        myButton2.setImage(UIImage(named: "forward")!, for: .normal)
        myButton2.addTarget(self, action: #selector(ViewController.forward), for: .touchUpInside)
        self.view.addSubview(myButton2)
        
        let myButton3 = UIButton(frame: CGRect(x: actionWidth * 2, y: 20, width: actionWidth, height: actionWidth))
        myButton3.setImage(UIImage(named: "refresh")!, for: .normal)
        myButton3.addTarget(self, action: #selector(ViewController.reload), for: .touchUpInside)
        self.view.addSubview(myButton3)
        
        let myButton4 = UIButton(frame: CGRect(x: actionWidth * 3, y: 20, width: actionWidth, height: actionWidth))
        myButton4.setImage(UIImage(named: "stop")!, for: .normal)
        myButton4.addTarget(self, action: #selector(ViewController.stop), for: .touchUpInside)
        self.view.addSubview(myButton4)
        
        let myButton5 = UIButton(frame: CGRect(x: Double(fullScreenSize.width) - goWidth, y: 20, width: goWidth, height: actionWidth))
        myButton5.setTitle("前往", for: .normal)
        myButton5.setTitleColor(UIColor.black, for: .normal)
        myButton5.addTarget(self, action: #selector(ViewController.go), for: .touchUpInside)
        self.view.addSubview(myButton5)
        
        // 建立一個 UITextField 用來輸入網址
        myTextField = UITextField(frame: CGRect(x: 0, y: 20.0 + CGFloat(actionWidth), width: fullScreenSize.width, height: 40))
        myTextField.text = "https://www.google.com"
        myTextField.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1)
        myTextField.clearButtonMode = .whileEditing
        myTextField.returnKeyType = .go
        myTextField.delegate = self
        self.view.addSubview(myTextField)
        
        // 建立 WKWebView
        myWebView = WKWebView(frame: CGRect(x: 0, y: 60.0 + CGFloat(actionWidth), width: fullScreenSize.width, height: fullScreenSize.height - 60 - CGFloat(actionWidth)))
        
        // 設置委任對象
        myWebView.navigationDelegate = self
        self.view.addSubview(myWebView)
        
        // 建立環狀進度條
        myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle:.gray)
        myActivityIndicator.center = CGPoint(x: fullScreenSize.width * 0.5, y: fullScreenSize.height * 0.5)
        self.view.addSubview(myActivityIndicator);
        
        // 先读取一次网址
        self.go()
    }
    
    
//    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Swift.Void) {
//
//        print("/\(navigationResponse.response.url!) navigationResponse" )
//
//        decisionHandler(.allow)
//    }
//
//    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Swift.Void) {
//
//        print(navigationAction.request.url!)
//        print("/\(navigationAction.request.url!) navigationAction" )
//
//        decisionHandler(.allow)
//    }
    
    
    @objc func back() {
        // 上一頁
        myWebView.goBack()
    }
    
    @objc func forward() {
        // 下一頁
        myWebView.goForward()
    }
    
    @objc func reload() {
        // 重新读取
        myWebView.reload()
    }
    
    @objc func stop() {
        // 取消读取
        myWebView.stopLoading()
        
        // 隐藏状态进度条
        myActivityIndicator.stopAnimating()
    }
    
    @objc func go() {
        // 隐藏键盘
        self.view.endEditing(true)
        
        // 前往网址
        let url = URL(string:myTextField.text!)
        let urlRequest = URLRequest(url: url!)
        myWebView.load(urlRequest)
        
        // 可以設置 HTML 內容到一個常數
        // 用来载入一个静态网页内容
//        let url1 = URL(string:"file:///Users/tzh/Downloads/test-webview%20(1).html")
//        myWebView.loadFileURL(url1!, allowingReadAccessTo: url1!)

    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.go()
        
        return true
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        // 显示进度条
        myActivityIndicator.startAnimating()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // 隐藏进度条
        myActivityIndicator.stopAnimating()
        
        // 更新網址列的內容
        if let currentURL = myWebView.url {
            myTextField.text = currentURL.absoluteString
        }
    }
    
    
    // MARK: -清除缓存（wkWebView）
    @objc func removeCache() {
        let dateForm:NSDate = NSDate.init(timeIntervalSince1970: 0)
        
        if #available(iOS 9.0, *) {
            let websiteDataTypes:NSSet = WKWebsiteDataStore.allWebsiteDataTypes() as NSSet
            WKWebsiteDataStore.default().removeData(ofTypes: websiteDataTypes as! Set<String>, modifiedSince: dateForm as Date, completionHandler: {
                print("清空缓存(webView)")
            })
            
        } else {
            let libraryPath = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)[0]
            let cookiesFolderPath = libraryPath.appending("/Cookies")
            let err = Error.self
            print("/\(err)")
            try?FileManager.default.removeItem(atPath: cookiesFolderPath)
            
        }
    }
    
    //获取缓存大小
    @objc func fileSizeOfCache()-> Int {
        
        // 取出cache文件夹目录 缓存文件都在这个目录下
        let cachePath = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.cachesDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first
        //缓存目录路径
        print(cachePath!)
        
        // 取出文件夹下所有文件数组
        let fileArr = FileManager.default.subpaths(atPath: cachePath!)
        
        //快速枚举出所有文件名 计算文件大小
        var size = 0
        for file in fileArr! {
            
            // 把文件名拼接到路径中
            let path = cachePath?.appending("/\(file)")
            // 取出文件属性
            let floder = try! FileManager.default.attributesOfItem(atPath: path!)
            // 用元组取出文件大小属性
            for (abc, bcd) in floder {
                // 累加文件大小
                if abc == FileAttributeKey.size {
                    size += (bcd as AnyObject).integerValue
                }
            }
        }
        
        let mm = size / 1024 / 1024
        print("/\(mm)",mm)
        return mm
    }
    
    // MARK: -缓存路径
    
    // 读取缓存大小
//    @objc func returnCacheSize() -> String {
    
//        let cacheSize = String(format: "%.2", ViewController.forderSizeAtPath(folderPath: NSHomeDirectory()))
//        print("/\(cacheSize).......0000000",cacheSize)
//        return String(format: "%.2", ViewController.forderSizeAtPath(folderPath: NSHomeDirectory()))
        
        
//    }
    
//    @objc func cacheSize() -> String {
//
//            let basePath = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.cachesDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first
//            let fileManager = FileManager.default
//
//            func caculateCache() -> Float{
//                var total: Float = 0
//                if fileManager.fileExists(atPath: basePath!){
//                    let childrenPath = fileManager.subpaths(atPath: basePath!)
//                    if childrenPath != nil{
//                        for path in childrenPath!{
//                            let childPath = basePath?.appending("/").appending(path)
//                            do{
//                                let attr = try FileManager.default.attributesOfItem(atPath: childPath!)
//
//                                let fileSize = attr[FileAttributeKey.size] as! Float
//                                total += fileSize
//
//                            }catch _{
//
//                            }
//                        }
//                    }
//                }
//
//                return total
//            }
//
//
//            let totalCache = caculateCache()
//            return NSString(format: "%.2f MB", totalCache / 1024.0 / 1024.0 ) as String
//
//    }
    
    // 清除缓存 自己决定清除缓存的位置
    func cleanCache(competion:()->Void) {
        ViewController.deleteFolder(path: NSHomeDirectory() + "/Documents")
        ViewController.deleteFolder(path: NSHomeDirectory() + "/Library")
        ViewController.deleteFolder(path: NSHomeDirectory() + "/tmp")
        competion()
    }
    // 删除单个文件
    static func deleteFile(path: String) {
        let manage = FileManager.default
        do {
            try manage.removeItem(atPath: path)
            } catch {
            
            }
    }
    
    static func deleteFolder(path: String) {
        let manage = FileManager.default
        if !manage.fileExists(atPath: path) {
        }
        let childFilePath = manage.subpaths(atPath: path)
        for path_1 in childFilePath! {
            let fileAbsoluePath = path+"/"+path_1
            ViewController.deleteFile(path: fileAbsoluePath)
        }
    }
    
    // 计算单个文件的大小
    static func returnFileSize(path:String) -> Double {
        let manager = FileManager.default
        var fileSize:Double = 0
        do {
            let attr = try manager.attributesOfItem(atPath: path)
            fileSize = Double(attr[FileAttributeKey.size] as! UInt64)
            let dict = attr as NSDictionary
            fileSize = Double(dict.fileSize())
            } catch {
            dump(error)
            }
        return fileSize/1024/1024
    }
    
    // 遍历所有子目录， 并计算文件大小
    static func forderSizeAtPath(folderPath:String) -> Double {
        let manage = FileManager.default
        if !manage.fileExists(atPath: folderPath) {
            return 0
            }
        let childFilePath = manage.subpaths(atPath: folderPath)
        var fileSize:Double = 0
        for path in childFilePath! {
            let fileAbsoluePath = folderPath+"/"+path
            fileSize += ViewController.returnFileSize(path: fileAbsoluePath)
            }
        return fileSize
    }
    

    
}

