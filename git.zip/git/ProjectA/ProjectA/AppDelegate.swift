//
//  AppDelegate.swift
//  ProjectA
//
//  Created by tzh on 2017/11/09.
//  Copyright © 2017年 tzh. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?

    @objc func application(_ application: UIApplication, willFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey : Any]? = nil) -> Bool{
        
        
        URLProtocol.registerClass(MyURLProtocol.self)
        print("...0000")
        return true
    }
}
