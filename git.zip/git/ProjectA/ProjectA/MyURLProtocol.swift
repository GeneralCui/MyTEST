//
//  MyURLProtocol.swift
//  ProjectA
//
//  Created by tzh on 2017/11/14.
//  Copyright © 2017年 tzh. All rights reserved.
//

import Foundation
import UIKit

class MyURLProtocol: URLProtocol {
    
    override class func canInit(with request: URLRequest) -> Bool {
        
        // wkWebView 没走进来这个方法，但UIwebview走进了
        print("kldjflas;dfj")
        print(request.url!)
        
        return false
    }
}
