

#import "ViewController.h"

@interface ViewController () <UITextFieldDelegate>

@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UIButton *button;
@property (nonatomic, strong) UIProgressView *progressView;

@end

@implementation ViewController

- (void)dealloc {
    [self.webView removeObserver:self forKeyPath:@"estimatedProgress"];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    // webView
    self.webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 100, self.view.bounds.size.width, self.view.bounds.size.height - 100)];
//    self.webView.allowsBackForwardNavigationGestures = YES;
//    self.webView.navigationDelegate = self;
    [self.view addSubview:self.webView];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.google.com"]]];
    
    // UIButton
    self.button = [[UIButton alloc]init];
    self.button.frame = CGRectMake(370, 50, 30, 30);
    [self.button.layer setCornerRadius:5.0];

    // Title 时
    // 设置按钮上显示的文字
    [self.button setTitle:@"go" forState:UIControlStateNormal];
    //设置文字颜色
    [self.button setTitleColor:[UIColor darkGrayColor] forState:UIControlStateHighlighted];
    self.button.backgroundColor = [UIColor colorWithRed:48.0/255.0 green:121.0/255.0 blue:237.0/255.0 alpha:1.0];
    
    [self.view addSubview:self.button];
    // 点击事件
    [self.button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];

    // textfield
    self.textField = [[UITextField alloc]initWithFrame:CGRectMake(20, 50, 340, 30)];
//     self.textField.layer.borderWidth = 1.0f;
    self.textField.keyboardType = UIKeyboardTypeDefault;
    self.textField.borderStyle = UITextBorderStyleRoundedRect;
    self.textField.layer.borderColor = [UIColor colorWithRed:217.0/255.0 green:217.0/255.0 blue:217.0/255.0 alpha:1.0].CGColor;
   
    // 关闭首字母大写
    self.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
//    self.textField.layer.borderColor = [UIColor grayColor].CGColor;
    self.textField.backgroundColor = [UIColor colorWithRed:205.0/255.0 green:205.0/255.0 blue:205.0/255.0 alpha:0.5];
    self.textField.font = [UIFont fontWithName:@"Arial" size:20.0f];
    self.textField.textColor = [UIColor blackColor];
    self.textField.clearButtonMode = UITextFieldViewModeAlways;
    self.textField.delegate = self;
    [self.view addSubview:self.textField];
    
    self.progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(8, 90, [[UIScreen mainScreen] bounds].size.width - 16, 2)];
    self.progressView.backgroundColor = [UIColor blueColor];
    self.progressView.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
    [self.view addSubview:self.progressView];
    
    [self.webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
}

#pragma mark - 监听 kvo
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        self.progressView.progress = self.webView.estimatedProgress;
        if (self.progressView.progress == 1) {
            __weak typeof (self)weakSelf = self;
            [UIView animateWithDuration:0.2f delay:0.3f options:UIViewAnimationOptionCurveEaseOut animations:^{
                weakSelf.progressView.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
            } completion:^(BOOL finished) {
                weakSelf.progressView.hidden = YES;
            }];
        }
    } else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)buttonClick{
    
    NSURL *url = [[NSURL alloc] initWithString:self.textField.text];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [self.webView loadRequest:request];
    NSLog(@"点击事件测试");
}

//#pragma mark - WKNavigationDelegate
//- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
//
//    self.textField.text = [NSString stringWithFormat:@"%@",webView.URL];
//    NSLog(@"didStartProvisionalNavigation");
//
//    self.progressView.hidden = NO;
//    [self.view bringSubviewToFront:self.progressView];
//}
//- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
//
//    // 页面开始返回时
//    NSLog(@"didCommitNavigation");
//}
//- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
//    // 页面加载完成后
//    NSLog(@"didFinishNavigation");
//}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
