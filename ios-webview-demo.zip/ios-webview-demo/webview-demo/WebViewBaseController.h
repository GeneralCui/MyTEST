//
//  WebviewBase.h
//  webview-demo
//
//  Created by Zhihui Tian on 2017/11/21.
//  Copyright © 2017年 intasect. All rights reserved.
//

#ifndef WebviewBaseController_h
#define WebviewBaseController_h
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface WebViewBaseController : UIViewController<UITextFieldDelegate, WKUIDelegate, WKNavigationDelegate>

@property (nonatomic, strong) WKWebView *wkWebView;
@property (nonatomic, strong) UIWebView *uiWebView;

@property (nonatomic, strong) UITextField *addressBar;
@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIButton *forwardButton;
@property (nonatomic, strong) UIButton *clearButton;
@property (nonatomic) NSString *currentURL;
@property (nonatomic, strong) UIProgressView *progressView;

@property (nonatomic, strong) NSURLRequest *tmpRequest;
@property (nonatomic, assign) BOOL isStaff;

@end
#endif /* WebviewBaseController_h */
