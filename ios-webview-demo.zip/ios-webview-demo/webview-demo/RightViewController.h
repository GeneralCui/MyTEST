//
//  RightViewController.h
//  WKWebviewTest
//
//  Created by tzh on 2017/11/17.
//  Copyright © 2017年 mirroon. All rights reserved.
//
//
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "WebViewBaseController.h"

@interface RightViewController : WebViewBaseController<WKUIDelegate,WKNavigationDelegate>

@end

