//
//  myTabBarController.m
//  WKWebviewTest
//
//  Created by tzh on 2017/11/17.
//  Copyright © 2017年 mirroon. All rights reserved.
//

#import "MyTabBarController.h"
#import "LeftViewController.h"
#import "RightViewController.h"

@interface MyTabBarController ()

@end

@implementation MyTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    LeftViewController *leftVC = [[LeftViewController alloc] init];
    RightViewController *rightVC = [[RightViewController alloc] init];
    NSArray *views = @[leftVC, rightVC];
    [self setViewControllers:views animated:NO];
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSFontAttributeName:[UIFont fontWithName:@"AmericanTypewriter" size:18.0f]} forState:UIControlStateNormal];
    
    UITabBarItem *item = [self.tabBar.items objectAtIndex:0];
    item.image = [self makeThumbnailFromText:@"UIWebView"];
    
    UITabBarItem *item2 = [self.tabBar.items objectAtIndex:1];
    item2.image = [self makeThumbnailFromText:@"WKWebView"];
}

//自定义UITabBarController 的高度
- (void)viewWillLayoutSubviews{
//    self.selectedViewController.view.frame = CGRectMake(0, 0, 100, 100);
    UIView *u1 = [self.view.subviews objectAtIndex:0];
    u1.frame = CGRectMake(0, 0, 100, self.tabBar.frame.size.width);
//    self.view.frame =
}

- (UIImage *)makeThumbnailFromText:(NSString *)string {
    // some variables that control the size of the image we create, what font to use, etc.
    
    CGSize imageSize = CGSizeMake(200, 48);
    CGFloat fontSize = 22.0;
    NSString *fontName = @"Helvetica-Bold";
    UIFont *font = [UIFont fontWithName:fontName size:fontSize];
    CGFloat lineSpacing = fontSize * 1;
    
    // set up the context and the font
    
    UIGraphicsBeginImageContextWithOptions(imageSize, false, 0);
    NSDictionary *attributes = @{NSFontAttributeName: font};
    
    // some variables we use for figuring out the words in the string and how to arrange them on lines of text
    
    NSArray <NSString *> *words = [string componentsSeparatedByString:@" "];
    NSMutableArray <NSDictionary *> *lines = [NSMutableArray array];
    NSString *lineThusFar;
    CGSize sizeThusFar = CGSizeZero;
    
    // let's figure out the lines by examining the size of the rendered text and seeing whether it fits or not and
    // figure out where we should break our lines (as well as using that to figure out how to center the text)
    
    for (NSString *word in words) {
        NSString *currentLine = lineThusFar ? [NSString stringWithFormat:@"%@ %@", lineThusFar, word] : word;
        CGSize size = [currentLine sizeWithAttributes: attributes];
        if (size.width > imageSize.width && lineThusFar) {
            [lines addObject:@{@"text": lineThusFar, @"size": [NSValue valueWithCGSize: sizeThusFar]}];
            lineThusFar = word;
            sizeThusFar = [word sizeWithAttributes: attributes];
        } else {
            lineThusFar = currentLine;
            sizeThusFar = size;
        }
    }
    if (lineThusFar) {
        [lines addObject:@{@"text": lineThusFar, @"size": [NSValue valueWithCGSize: sizeThusFar]}];
    }
    
    // now write the lines of text we figured out above
    
    CGFloat totalSize = (lines.count - 1) * lineSpacing + fontSize;
    CGFloat topMargin = (imageSize.height - totalSize) / 2.0;
    
    for (NSInteger i = 0; i < lines.count; i++) {
        CGFloat x = (imageSize.width - [lines[i][@"size"] CGSizeValue].width) / 2.0;
        CGFloat y = topMargin + i * lineSpacing;
        [lines[i][@"text"] drawAtPoint:CGPointMake(x, y) withAttributes: attributes];
    }
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
