//
//  LeftViewController.m
//  WKWebviewTest
//
//  Created by tzh on 2017/11/17.
//  Copyright © 2017年 mirroon. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "WebViewBaseController.h"
#import "LeftViewController.h"

@interface LeftViewController ()



@end

@implementation LeftViewController
-(void)childViewDidLoad{
    // webView
    self.uiWebView = [[UIWebView alloc] init];
    self.uiWebView.delegate = self;
    [self.view addSubview:self.uiWebView];
}
@end
