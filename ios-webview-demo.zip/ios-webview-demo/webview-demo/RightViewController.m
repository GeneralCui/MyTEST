//
//  RightViewController.m
//  WKWebviewTest
//
//  Created by tzh on 2017/11/17.
//  Copyright © 2017年 mirroon. All rights reserved.
//

#import "RightViewController.h"
#import <WebKit/WebKit.h>

@interface RightViewController()
@end

@implementation RightViewController
-(void)childViewDidLoad{
    // wkWebView
    self.wkWebView = [[WKWebView alloc] init];
    self.wkWebView.allowsBackForwardNavigationGestures = YES;
    self.wkWebView.navigationDelegate = self;
    [self.view addSubview:self.wkWebView];
}
@end
